# Change Logs

<dl>
    <dt>2020-11-03</dt>
    <dd>Added full support for Linux</dd>
    <dd>Added (untested) partial support for Mac OS.</dd>
    <dd>Updated documentations with targeted instructions for Windows, Linux and Mac OS</dd>
    <dd></dd>
    <dt>2019-04-23</dt>
    <dd>Updated vscode configurations to latest version</dd>
    <dt>2018-08-28</dt>
    <dd>Updated the structure of c_cpp_properties.json in compliance with the latest vscode</dd>
    <dd>Updated indentions</dd>
    <dd>Added "Installation Process" section in README.md</dd>
    <dt>2018-02-08</dt>
    <dd>Restructured the repository for quicker setup</dd>
    <dd>Added editor configuration file for standard IDE changes</dd>
    <dt>2017-03-27</dt>
    <dd>Added vscode > c++ support</dd>
</dl>
